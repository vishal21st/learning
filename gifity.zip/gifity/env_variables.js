export const GIFY_API_ENDPOINT = process.env.VUE_APP_GIFY_API_HOST;
export const GIFY_API_KEY = process.env.VUE_APP_GIFY_API_KEY;
