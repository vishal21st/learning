import { GIFY_API_KEY } from '../../env_variables';

const GphApiClient = require('giphy-js-sdk-core');

export default GphApiClient(GIFY_API_KEY);
