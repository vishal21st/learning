<template>
  <div :class="classes">
    <GifTile :gifSrc="gif.images.fixed_height.webp"
    :staticImgSrc="gif.images.original_still.url"
    :height="gif.images.fixed_height.height"
    :width="gif.images.fixed_height.width"
    v-for="(gif, index) in list" :key="`${gif.id}${index}`"
    :title="gif.title"
    :index="index"/>
    <div class="empty-container" v-if="isEmpty">
      <img src="https://media1.giphy.com/media/2vlC9FMLSmqGs/200.webp" alt="empty">
    </div>
  </div>
</template>

<script>
import GifTile from '@/components/GifTile.vue';

export default {
  name: 'GifList',
  props: {
    list: {
      default: () => [],
      type: Array,
    },
  },
  components: { GifTile },
  computed: {
    classes: function() {
      return this.isEmpty ? 'gif-list is-empty' : 'gif-list'
    },
    isEmpty: function() {
      return this.list.length == 0
    }
  }
};
</script>
