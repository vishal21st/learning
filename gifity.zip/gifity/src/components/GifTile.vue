<template>
  <div class="gif-tile">
    <img :id="id" :src="_gifSrc" :alt="title" :height="height" :style="{backgroundColor: bgColor}">
  </div>
</template>
<script>
export default {
  name: 'GifTile',
  data() {
    return {
      _gifSrc: "",
      options: {
        root: null,
        rootMargin: '0px',
        threshold: 1.0
      },
      observer: null,
      id: `image-${this.index}`,
      bgColors: ['', '#00ff23', '#0056ff', '#ff0072'],
      bgColor: ''
    }
  },
  created: function() {
    this._gifSrc = this.staticImgSrc;
    this.observer = new IntersectionObserver(this.onIntersection, this.options);
    let index = parseInt((Math.random() * 3) + 1)
    this.bgColor = this.bgColors[index];
  },
  mounted: function() {
    this.observer.observe(document.querySelector(`#${this.id}`));
  },
  props: {
    gifSrc: {
      default: "",
      type: String
    },
    staticImgSrc: {
      default: "",
      type: String
    },
    index: {
      default: 1,
      type: Number
    },
    height: String,
    width: String,
    title: String
  },
  methods: {
    onIntersection(imageEntities) {
      let that = this;
      imageEntities.forEach(function (image) {
        if (image.isIntersecting) {
          that.observer.unobserve(image.target);
          that._gifSrc = that.gifSrc;
          image.target.src = that._gifSrc;
        }
      }) 
    }
  }
};
</script>
