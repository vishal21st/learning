<template>
  <div class="search-box">
    <input  type='text'
            :value="value"
            :placeholder="placeholder"
            v-on:keyup="handleKeyPress($event)">
  </div>
</template>


<script>
import debounce from '@/lib/debounce';

export default {
  name: 'SearchBox',
  props: {
    value: String,
    placeholder: String,
  },
  methods: {
    handleKeyPress: debounce(function ($event) {
      this.$emit('change', $event.target.value);
    }, 500),
  },
};
</script>
