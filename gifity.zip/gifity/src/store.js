import Vue from 'vue';
import Vuex from 'vuex';
import client from './api/gify';
import { SEARCH_SUCCESS, UPDATE_SEARCH_STATE } from './mutation_types';

Vue.use(Vuex);

export default new Vuex.Store({
  state: {
    gifs: [],
    loading: true,
    error: {},
    pagination: {},
    isSearching: false
  },
  getters: {
    gifs: state => state.gifs,
    pagination: state => state.pagination,
    isSearching: state => state.isSearching
  },
  mutations: {
    [SEARCH_SUCCESS]: (state, payload) => {
      state.gifs = payload.data;
      state.pagination = payload.pagination;
      state.isSearching = false
    },
    [UPDATE_SEARCH_STATE]: (state, payload) => {
      state.isSearching = payload
    }
  },
  actions: {
    trending({ commit, state }) {
      commit(UPDATE_SEARCH_STATE, true);
      client.trending("gifs", {})
        .then((response) => {
          commit(SEARCH_SUCCESS, {
            pagination: response.pagination,
            data: response.data
          });
          commit(UPDATE_SEARCH_STATE, false)
        })
        .catch((err) => {
          console.log(err)
          commit(UPDATE_SEARCH_STATE, false)
        })
    },
    search({ commit, state }, payload) {
      commit(UPDATE_SEARCH_STATE, true);
      const { query, offset = 0 } = payload;
      const { gifs } = state;
      client.search('gifs', { q: query, offset: offset })
        .then((response) => {
          if (offset > 1) {
            commit(SEARCH_SUCCESS, {
              pagination: response.pagination,
              data: [...gifs, ...response.data]
            });
          } else {
            commit(SEARCH_SUCCESS, response);
          }
          commit(UPDATE_SEARCH_STATE, false)
        })
        .catch((error) => {
          console.log(error);
          commit(UPDATE_SEARCH_STATE, false)
        });
    },
  },
});
