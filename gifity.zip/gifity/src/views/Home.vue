<template>
  <div class="home">
    <div class="progress-bar" v-show="isSearching"></div>
    <search-box v-on:change="handleInputChange"
      placeholder="Type in keyword"
      :value="''"/>
    <GifList :list="gifs"/>
    <div class="progress-bar" v-show="isSearching"></div>
  </div>
</template>

<script>
// @ is an alias to /src
import SearchBox from '@/components/SearchBox.vue';
import GifList from '@/components/GifList.vue';
import { mapGetters, mapActions } from 'vuex';
import throttle from '@/lib/throttle';
export default {
  name: 'home',
  components: { SearchBox, GifList },
  data() {
    return {
      searchInput: '',
      q: ''
    };
  },
  computed: {
    ...mapGetters(['gifs', 'pagination', 'isSearching']),
  },
  beforeMount() {
    this.trending();
    window.onscroll = throttle(this.handleScroll, 2000);
  },
  methods: {
    ...mapActions(['search', 'trending']),
    handleInputChange(query) {
      if (query) {
        this.query = query;
        this.search({query});
        return
      }
      this.trending();
    },
    handleScroll() {
      let { scrollTop, offsetHeight } = document.documentElement
      let bottomOfWindow = scrollTop + window.innerHeight > offsetHeight - 200;

      if (bottomOfWindow) {
        if (!this.isSearching && this.pagination.total_count 
        != this.gifs.length) {
          this.search({query: this.query, offset: this.pagination.offset + 1});
        }
      }
    }
  },
};
</script>
