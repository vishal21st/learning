import Vue from 'vue';
import axios from 'axios';
import App from './App.vue';
import router from './router';
import store from './store';
import './registerServiceWorker';
import { GIFY_API_KEY } from '../env_variables';

Vue.config.productionTip = false;
console.log(GIFY_API_KEY);
axios.defaults.headers.common['Access-Control-Allow-Origin'] = '*';

new Vue({
  router,
  store,
  render: h => h(App),
}).$mount('#app');
