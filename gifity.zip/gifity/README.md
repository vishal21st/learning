# gifity
It is a Single page application (SPA), built using Vuejs, Vuex

## Project setup
```
npm install
```
```
Add .env.local file at root 
```
```
Add following keys in .env.local
VUE_APP_GIFY_API_HOST = "http://api.giphy.com"
VUE_APP_GIFY_API_KEY=<Your gify api key>
```
### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```