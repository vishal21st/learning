import "./css/style.scss"
import Invoice  from "./js/Invoice"

let invoice = new Invoice()
invoice.render()