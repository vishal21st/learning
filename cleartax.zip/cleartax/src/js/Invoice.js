function getElement(id) {
  return document.getElementById(id);
}

function setElementValue(id, value) {
  getElement(id).innerHTML = value;
}

function getElementValue(id) {
  return getElement(id).innerHTML
}

const Invoice =  function() {
  this.selectors = {
    companyName: "company-name",
    merchantName: "merchant-name",
    companyGstin: "company-gstin",
    companyAdress: "company-adress",
    companyCity: "company-city",
    companyState: "company-state",
    invoiceNumber: "invoice-number",
    clientCompanyName: "client-company-name",
    clientGstin: "client-gstin",
    clientAddress: "client-address",
    clientCity: "client-city",
    clientState: "client-state",
    invoiceDate: "invoice-date",
    dueDate: "due-date"
  }

  this.store = {
    companyName: "company name",
    merchantName: "merchant name",
    companyGstin: "company gstin",
    companyAdress: "company adress",
    companyCity: "company city",
    companyState: "company state",
    invoiceNumber: "Invoice 1",
    clientCompanyName: "client company name",
    clientGstin: "client gstin",
    clientAddress: "client address",
    clientCity: "client city",
    clientState: "client state",
    invoiceDate: "invoice date",
    dueDate: "due-date",
  }
}

Invoice.prototype.render = function() {
  this.updateFields()
  this.listenFieldChange()
}


Invoice.prototype.update = function (option)  {
  this.store[option.key] = option.value
}

Invoice.prototype.updateFields = function () {
  for (let elementName in this.selectors) {
    setElementValue(this.selectors[elementName], this.store[elementName])
  }
}

Invoice.prototype.enumerateFields = function (block) {
  for (let elementName in this.selectors) {
    block(elementName, this.selectors[elementName])
  }
}

Invoice.prototype.onFieldChange = function (event) {
  let {innerHTML, name, id } = event.target
  this.store[name] = innerHTML
}

Invoice.prototype.listenFieldChange= function () {
  this.enumerateFields(function(fieldKey, fieldId) {
    let el = getElement(fieldId)
    el.addEventListener("input", this.onFieldChange.bind(this))
  }.bind(this))
}

export default Invoice;